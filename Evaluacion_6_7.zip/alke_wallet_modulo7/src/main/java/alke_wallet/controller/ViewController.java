package alke_wallet.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import alke_wallet.model.User;
import alke_wallet.service.BankingService;

@Controller
public class ViewController {
	
	@Autowired
    private BankingService bankingService;

    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(User user) {
        bankingService.registerUser(user);
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @GetMapping("/account")
    public String showAccount(Model model, @RequestParam String accountNumber) {
        double balance = bankingService.getBalance(accountNumber);
        model.addAttribute("balance", balance);
        model.addAttribute("accountNumber", accountNumber);
        return "account";
    }

    @PostMapping("/deposit")
    public String deposit(@RequestParam String accountNumber, @RequestParam double amount) {
        bankingService.deposit(accountNumber, amount);
        return "redirect:/account?accountNumber=" + accountNumber;
    }

    @PostMapping("/withdraw")
    public String withdraw(@RequestParam String accountNumber, @RequestParam double amount) {
        bankingService.withdraw(accountNumber, amount);
        return "redirect:/account?accountNumber=" + accountNumber;
    }

    @GetMapping("/transactions")
    public String showTransactions(Model model, @RequestParam String accountNumber) {
        model.addAttribute("transactions", bankingService.getTransactions(accountNumber));
        return "transactions";
    }
}
