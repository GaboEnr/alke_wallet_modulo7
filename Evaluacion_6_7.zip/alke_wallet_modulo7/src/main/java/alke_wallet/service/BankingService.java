package alke_wallet.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import alke_wallet.model.Account;
import alke_wallet.model.Transaction;
import alke_wallet.model.User;
import alke_wallet.repository.AccountRepository;
import alke_wallet.repository.TransactionRepository;
import alke_wallet.repository.UserRepository;

@Service
public class BankingService {
	@Autowired
	private UserRepository userRepository;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    public User registerUser(User user) {
        // Codificar la contraseña antes de guardar
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public double getBalance(String accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        return account.getBalance();
    }

    public void deposit(String accountNumber, double amount) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        account.setBalance(account.getBalance() + amount);
        accountRepository.save(account);

        Transaction transaction = new Transaction();
        transaction.setType("DEPOSIT");
        transaction.setAmount(amount);
        transaction.setDate(LocalDateTime.now());
        transaction.setAccount(account);
        transactionRepository.save(transaction);
    }

    public void withdraw(String accountNumber, double amount) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        if (account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            accountRepository.save(account);

            Transaction transaction = new Transaction();
            transaction.setType("WITHDRAW");
            transaction.setAmount(amount);
            transaction.setDate(LocalDateTime.now());
            transaction.setAccount(account);
            transactionRepository.save(transaction);
        } else {
            throw new RuntimeException("Insufficient balance");
        }
    }

    public List<Transaction> getTransactions(String accountNumber) {
        Account account = accountRepository.findByAccountNumber(accountNumber);
        return transactionRepository.findByAccount(account);
    }
    
}
