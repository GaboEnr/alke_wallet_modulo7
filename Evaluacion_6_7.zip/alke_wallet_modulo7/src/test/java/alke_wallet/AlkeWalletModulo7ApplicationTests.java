package alke_wallet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlkeWalletModulo7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
